function dados(){
    var nome = document.getElementById("nome").value;
    var endereco = document.getElementById("endereco").value;
    var telefone = document.getElementById("telefone").value;
    alert("Nome: " + nome + "\n Endereço: " + endereco + "\n Telefone: " + telefone);
}