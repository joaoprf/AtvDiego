function numint(){
    var n1 = document.getElementById("n1").value;
    var n2 = document.getElementById("n2").value;
    alert(n1 + "\n" + n2);
}