function imprimir(){
    var n = document.getElementById("n").value;
    resultado = parseInt(n) / 3;
    alert(resultado);
}