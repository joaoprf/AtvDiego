function calcular(){
    var n1 = document.getElementById("n1").value;
    var n2 = document.getElementById("n2").value;
    multiplicacao = parseInt(n1) * parseInt(n2);
    alert(multiplicacao);
}