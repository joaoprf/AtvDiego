function numint(){
    var n = document.getElementById("n").value;
    antecessor = parseInt(n) - 1;
    sucessor = parseInt(n) + 1;
    alert("Seu antecessor é " + antecessor + " e o seu sucessor é " + sucessor);
}