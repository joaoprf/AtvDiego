function numint(){
    var n = document.getElementById("n").value;
    alert("O número inteiro digitado foi " + n);
}