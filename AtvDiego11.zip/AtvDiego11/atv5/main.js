function media()
{
    x = 4;
    y = 12;
    z = 15;
    resultado = (x + y + z) / 3;
    alert(resultado);
}