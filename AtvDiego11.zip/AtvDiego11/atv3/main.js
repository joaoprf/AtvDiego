alert("A programação é aprendida escrevendo programas. \n Brian Kernighan");
