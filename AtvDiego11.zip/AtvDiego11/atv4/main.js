function produto(x,y)
{
    x = 25;
    y = 27;
    resultado = x * y;
    alert(resultado);
}