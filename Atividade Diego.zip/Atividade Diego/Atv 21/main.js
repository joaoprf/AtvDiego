function Imprimir(){
    var base = document.getElementById("base").value;
    var altura = document.getElementById("altura").value;
   area = (parseFloat(base) * parseFloat(altura)) / 2;
   alert("A área do triângulo é: " + area);
}