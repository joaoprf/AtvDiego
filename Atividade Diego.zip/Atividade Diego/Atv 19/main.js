function Imprimir(){
    var salariobase = document.getElementById("salario").value;
    gratificacao = 50;
    imposto = parseFloat(salariobase) * 0.10;
    novosalario = parseFloat(salariobase) + gratificacao - imposto;
   alert("O valor do novo salário é: R$" + novosalario);
}