function Imprimir(){
    var deposito = document.getElementById("deposito").value;
    var juros = document.getElementById("juros").value;
    rendimento = parseFloat(deposito) * (parseFloat(juros) / 100);
    total = parseFloat(deposito) + parseFloat(rendimento);
   alert("O valor do rendimento é: R$" + rendimento + "\n O valor total após o rendimento é de: R$" + total);
}