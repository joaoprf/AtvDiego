function Imprimir(){
    var valorsal = document.getElementById("salario").value;
    novosalario = parseFloat(valorsal) + (parseFloat(valorsal) * 0.25);
   alert("O valor do novo salário é: R$" + novosalario);
}