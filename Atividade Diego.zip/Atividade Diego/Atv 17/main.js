function Imprimir(){
    var salario = document.getElementById("salario").value;
    var aumentop = document.getElementById("aumento").value;
    aumento = parseFloat(salario) * (parseFloat(aumentop) / 100);
    novosalario = parseFloat(salario) + parseFloat(aumento);
   alert("O valor do aumento é: R$" + aumento + "\n O valor do novo salário é: R$" + novosalario);
}