function Imprimir(){
    var n1 = document.getElementById("n1").value;
    var n2 = document.getElementById("n2").value;
    dividendo = n1;
    divisor = n2;
    quociente = dividendo / divisor;
    resto = dividendo % divisor;
   alert("Dividendo: " + dividendo + "\nDivisor: " + divisor + "\nQuociente: " + quociente + "\nResto: " + resto);
}