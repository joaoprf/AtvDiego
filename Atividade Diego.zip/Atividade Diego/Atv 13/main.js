function Imprimir(){
    var n1 = document.getElementById("n1").value;
    var n2 = document.getElementById("n2").value;
    var n3 = document.getElementById("n3").value;
    var n4 = document.getElementById("n4").value;
    calcular = parseInt(n1) + parseInt(n2) + parseInt(n3) + parseInt(n4); 
    alert(calcular);
}